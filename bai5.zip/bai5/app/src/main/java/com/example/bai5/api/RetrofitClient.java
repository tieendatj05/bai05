package com.example.bai5.api;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitClient {
    // Đổi đường dẫn API tại đây như yêu cầu
    private static final String BASE_URL = "http://app.iotstar.vn:8081/";
    private static Retrofit retrofit = null;

    public static APIService getService() {
        if (retrofit == null) {
            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit.create(APIService.class);
    }
}