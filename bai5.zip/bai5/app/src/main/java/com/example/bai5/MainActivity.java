package com.example.bai5;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.bai5.adapter.CategoryAdapter;
import com.example.bai5.api.RetrofitClient;
import com.example.bai5.model.Category;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    RecyclerView rcCate;
    CategoryAdapter categoryAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Ánh xạ RecyclerView
        rcCate = findViewById(R.id.rc_category);
        rcCate.setHasFixedSize(true);

        // SỬA LỖI: Thiết lập LayoutManager để cuộn theo chiều ngang
        rcCate.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));

        // Gọi hàm lấy dữ liệu
        GetCategory();
    }

    private void GetCategory() {
        // Gọi API từ RetrofitClient
        RetrofitClient.getService().getCategories().enqueue(new Callback<List<Category>>() {
            @Override
            public void onResponse(Call<List<Category>> call, Response<List<Category>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    // Lấy dữ liệu thành công
                    List<Category> list = response.body();
                    categoryAdapter = new CategoryAdapter(MainActivity.this, list);
                    rcCate.setAdapter(categoryAdapter);
                } else {
                    Toast.makeText(MainActivity.this, "Không thể tải dữ liệu", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<List<Category>> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Lỗi kết nối: " + t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
}