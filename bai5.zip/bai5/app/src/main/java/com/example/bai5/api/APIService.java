package com.example.bai5.api;

import com.example.bai5.model.Category;
import java.util.List;
import retrofit2.Call;
import retrofit2.http.GET;

public interface APIService {
    // Đường dẫn tính từ Base URL
    @GET("appfoods/categories.php")
    Call<List<Category>> getCategories();
}