package com.example.bai5.model; // Thay bằng package của bạn

import com.google.gson.annotations.SerializedName;

public class Category {
    // Ánh xạ các trường JSON từ API
    @SerializedName("id")
    private int id;

    @SerializedName("name")
    private String name;

    @SerializedName("images")
    private String images;

    @SerializedName("description")
    private String description;

    // Constructor, Getter và Setter
    public int getId() { return id; }
    public String getName() { return name; }
    public String getImages() { return images; }
    public String getDescription() { return description; }
}