package com.example.bai4;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.annotation.Nullable;

public class DatabaseHandler extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "Notes.sqlite";
    private static final int DATABASE_VERSION = 2;

    // Bảng Notes
    private static final String TABLE_NOTES = "Notes";
    private static final String COLUMN_NOTES_ID = "Id";
    private static final String COLUMN_NOTES_NAME = "NameNotes";

    // Bảng UserAccounts
    private static final String TABLE_USER_ACCOUNTS = "UserAccounts";
    private static final String COLUMN_USER_ID = "Id";
    private static final String COLUMN_USER_EMAIL = "Email";
    private static final String COLUMN_USER_PASSWORD = "Password";


    public DatabaseHandler(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Truy vấn không trả kết quả: CREATE, INSERT, UPDATE, DELETE
    public void QueryData(String sql) {
        SQLiteDatabase database = getWritableDatabase();
        database.execSQL(sql);
    }

    // Truy vấn có trả kết quả: SELECT
    public Cursor GetData(String sql) {
        SQLiteDatabase database = getReadableDatabase();
        return database.rawQuery(sql, null);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Tạo bảng Notes
        String createNotesTable = String.format("CREATE TABLE %s(%s INTEGER PRIMARY KEY AUTOINCREMENT, %s VARCHAR(200))", TABLE_NOTES, COLUMN_NOTES_ID, COLUMN_NOTES_NAME);
        db.execSQL(createNotesTable);

        // Tạo bảng UserAccounts
        String createUserAccountsTable = String.format("CREATE TABLE %s(%s INTEGER PRIMARY KEY AUTOINCREMENT, %s VARCHAR(200), %s VARCHAR(200))", TABLE_USER_ACCOUNTS, COLUMN_USER_ID, COLUMN_USER_EMAIL, COLUMN_USER_PASSWORD);
        db.execSQL(createUserAccountsTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Xóa bảng cũ nếu tồn tại
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NOTES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER_ACCOUNTS);
        // Tạo lại bảng mới
        onCreate(db);
    }

    // --- Ghi chú (Notes) Functions ---
    public void addNote(String noteName) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NOTES_NAME, noteName);
        db.insert(TABLE_NOTES, null, values);
    }

    public void updateNote(String newName, int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NOTES_NAME, newName);
        db.update(TABLE_NOTES, values, COLUMN_NOTES_ID + " = ?", new String[]{String.valueOf(id)});
    }

    public void deleteNote(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NOTES, COLUMN_NOTES_ID + " = ?", new String[]{String.valueOf(id)});
    }

    // --- Người dùng (User) Functions ---
    public void addUser(String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_EMAIL, email);
        values.put(COLUMN_USER_PASSWORD, password);
        db.insert(TABLE_USER_ACCOUNTS, null, values);
    }

    public boolean checkUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_USER_ID};
        String selection = COLUMN_USER_EMAIL + " = ?" + " AND " + COLUMN_USER_PASSWORD + " = ?";
        String[] selectionArgs = {email, password};
        Cursor cursor = db.query(TABLE_USER_ACCOUNTS, columns, selection, selectionArgs, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        return count > 0;
    }
}