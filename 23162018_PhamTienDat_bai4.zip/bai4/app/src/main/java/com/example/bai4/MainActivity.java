package com.example.bai4;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    DatabaseHandler databaseHandler;
    ListView listView;
    ArrayList<NotesModel> arrayList;
    NotesAdapter adapter;
    FloatingActionButton fabAddNote;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1. Ánh xạ ListView và FAB
        listView = findViewById(R.id.listView1);
        fabAddNote = findViewById(R.id.fab_add_note);

        arrayList = new ArrayList<>();
        adapter = new NotesAdapter(this, R.layout.row_notes, arrayList);
        listView.setAdapter(adapter);

        // 2. Khởi tạo Database
        databaseHandler = new DatabaseHandler(this);

        // Thêm dữ liệu mẫu nếu bảng trống
        Cursor cursor = databaseHandler.GetData("SELECT * FROM Notes");
        if (cursor.getCount() == 0) {
            databaseHandler.addNote("Ví dụ SQLite 1");
            databaseHandler.addNote("Ví dụ SQLite 2");
            databaseHandler.addNote("Ví dụ SQLite 1");
            databaseHandler.addNote("Ví dụ SQLite 2");
            databaseHandler.addNote("Ví dụ SQLite 2");
            databaseHandler.addNote("Ví dụ SQLite 3");
        }
        cursor.close();

        // 3. Load dữ liệu
        GetDataNotes();

        // 4. Bắt sự kiện cho FAB
        fabAddNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogThem();
            }
        });
    }

    // Hàm lấy dữ liệu từ SQLite đổ vào List
    private void GetDataNotes() {
        Cursor cursor = databaseHandler.GetData("SELECT * FROM Notes");
        arrayList.clear();
        while (cursor.moveToNext()){
            arrayList.add(new NotesModel(
                    cursor.getInt(0),
                    cursor.getString(1)
            ));
        }
        adapter.notifyDataSetChanged();
        cursor.close();
    }

    // --- Dialog Thêm ---
    private void DialogThem(){
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_notes);

        TextView tvTitle = dialog.findViewById(R.id.textviewTitle);
        tvTitle.setText("THÊM CÔNG VIỆC"); // Đặt tiêu đề
        EditText edtTen = dialog.findViewById(R.id.editTextName);
        Button btnThem = dialog.findViewById(R.id.buttonXacNhan);
        Button btnHuy = dialog.findViewById(R.id.buttonHuy);

        btnThem.setText("Thêm");

        btnThem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tenCV = edtTen.getText().toString().trim();
                if(tenCV.equals("")){
                    Toast.makeText(MainActivity.this, "Vui lòng nhập tên!", Toast.LENGTH_SHORT).show();
                }else{
                    databaseHandler.addNote(tenCV);
                    Toast.makeText(MainActivity.this, "Đã thêm!", Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                    GetDataNotes();
                }
            }
        });

        btnHuy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    // --- Dialog Sửa ---
    public void DialogCapNhatNotes(String ten, int id){
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_notes);

        TextView tvTitle = dialog.findViewById(R.id.textviewTitle);
        tvTitle.setText("CẬP NHẬT"); // Đặt tiêu đề
        EditText edtTen = dialog.findViewById(R.id.editTextName);
        Button btnXacNhan = dialog.findViewById(R.id.buttonXacNhan);
        Button btnHuy = dialog.findViewById(R.id.buttonHuy);

        edtTen.setText(ten);
        btnXacNhan.setText("Cập nhật");

        btnXacNhan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tenMoi = edtTen.getText().toString().trim();
                databaseHandler.updateNote(tenMoi, id);
                Toast.makeText(MainActivity.this, "Đã cập nhật!", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
                GetDataNotes();
            }
        });

        btnHuy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    // --- Dialog Xóa ---
    public void DialogXoaCV(String ten, final int id){
        AlertDialog.Builder dialogXoa = new AlertDialog.Builder(this);
        dialogXoa.setMessage("Bạn có muốn xóa công việc '" + ten + "' không?");
        dialogXoa.setPositiveButton("Có", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                databaseHandler.deleteNote(id);
                Toast.makeText(MainActivity.this, "Đã xóa!", Toast.LENGTH_SHORT).show();
                GetDataNotes();
            }
        });
        dialogXoa.setNegativeButton("Không", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        dialogXoa.show();
    }
}